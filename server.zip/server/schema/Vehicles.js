var mongoose = require("mongoose");
var connectionString = "mongodb://uday_pydi:Itsmylife1@ds061158.mlab.com:61158/smart_vehico"


mongoose.Promise = global.Promise;mongoose.connect(connectionString);

var vehicleSchema = new mongoose.Schema({
  speed: String,
  latitude: String,
  longitude: String,
  speed: String,
  altitude: String,
  accuracy: String,
});

var User = mongoose.model("User", vehicleSchema);

module.exports = User;
